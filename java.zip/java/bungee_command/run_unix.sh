#!/bin/sh
java -Xmx32M -Xms32M -jar bungee-dist.jar